package main.notification_system;

public interface Observer {
    void update(Notification notification);
}
